export const checkEmail = async(req, res) => {
	
}